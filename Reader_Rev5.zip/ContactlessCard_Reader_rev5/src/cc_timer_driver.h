/*
 * cc_timer_driver.h
 *
 *  Created on: Feb 23, 2021
 *      Author: xps
 */

#ifndef SRC_CC_TIMER_DRIVER_H_
#define SRC_CC_TIMER_DRIVER_H_

/* includes */
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdint.h>
#include <ti/drivers/Timer.h>
#include "ti_drivers_config.h"
#include "CCReaderMainThread.h"

/* function prototypes */
void CC_Timer_Init(void);
void CC_Timer_Callback(Timer_Handle handle, int_fast16_t status);
void CC_Timeout_Start(uint32_t ms_timeout);
uint8_t CC_Get_Timeout_Status(void);
void CC_Reset_Timeout(void);
void CC_Timeout_Cancel(void);
void CC_Blocking_Delay(uint32_t ms_delay);


#endif /* SRC_CC_TIMER_DRIVER_H_ */
