/*
 * cc_uart_driver.h
 *
 *  Created on: Feb 22, 2021
 *      Author: xps
 */

#ifndef CC_UART_DRIVER_H_
#define CC_UART_DRIVER_H_

/* includes */
#include <stdint.h>
/* TI-DRIVERS Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/SPI.h>
//#include <ti/drivers/UART.h>
#include <ti/drivers/Power.h>
#include <ti/devices/cc32xx/driverlib/pin.h>
#include <ti/drivers/net/wifi/simplelink.h>
// cc defines
#include "uart_term.h"
#include "m6e_driver.h"
#include "semaphore.h"
#include "CCReaderMainThread.h"

// GLOBALS //

bool readElesim;
static uint8_t dataFromElesim[4];

// README:
//
// IF DEVBOARD - SET UP SYSCFG W/2 UARTS THE FOLLOWING WAY:
// NAME: UART_0_DEBUG_DEVBOARD
// BUS: UART0
// TXPIN: P55/GP01
// RXPIN: P57/GP02
//
// NAME: UART_1_TO_M6E
// BUS: UART1
// TXPIN: P07/GP16
// RXPIN: P08/GP17
//
// ///////////////////////////////////////////////////////////////////////
//
// IF USING REV2 - SETUP SYSCFG W/2 UARTS THE FOLLOWING WAY
// NAME: UART_1_DEBUG
// BUS: UART1
// TXPIN: P55/GP01
// RXPIN: P57/GP02
//
// NAME: UART_0_TO_M6E
// BUS: UART0
// TXPIN: P03/GP12
// RXPIN: P04/GP13

//#define UART_USING_DEVBOARD
#define UART_USING_REV2
#define UART_USING_ELESIM

/* local function prototypes */
// init functions
void CC_Debug_UART_Init(void);
void CC_Reader_UART_Init(void);
void CC_Elesim_UART_Init(void);
// reader functions
void CC_UART_Write_Callback_Reader(UART_Handle handle, void *buf, size_t count);
void CC_UART_Read_Callback_Reader(UART_Handle handle, void *buf, size_t count);
uint8_t CC_Get_UART_Write_Status_Reader(void);
uint8_t CC_Get_UART_Read_Status_Reader(void);
void CC_Start_UART_Write_Reader(const uint8_t * buffer, size_t size);
void CC_Start_UART_Read_Reader(uint8_t * buffer, size_t size);
uint8_t CC_Get_UART_Busy_Status_Reader(void);
void CC_UART_Read_Cancel_Reader(void);
// elesim functions
void CC_UART_Write_Callback_Elesim1(UART_Handle handle, void *buf, size_t count);
void CC_UART_Read_Callback_Elesim(UART_Handle handle, void *buf, size_t count);
uint8_t CC_Get_UART_Write_Status_Elesim(void);
uint8_t CC_Get_UART_Read_Status_Elesim(void);
void CC_Start_UART_Write_Elesim(const uint8_t * buffer, size_t size);
void CC_Start_UART_Read_Elesim(uint8_t * buffer, size_t size);
uint8_t CC_Get_UART_Busy_Status_Elesim(void);
void CC_UART_Read_Cancel_Elesim(void);

#endif /* CC_UART_DRIVER_H_ */
