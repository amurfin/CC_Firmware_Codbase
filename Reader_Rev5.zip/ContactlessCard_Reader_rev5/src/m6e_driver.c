/*
 * m6e_driver.c
 *
 *  Created on: Nov 22, 2020
 *      Author: xps
 */

#include "m6e_driver.h"

/* static variables */
static UART_Handle uxhandle;

//Comes from serial_reader_l3.c
//ThingMagic-mutated CRC used for messages.
//Notably, not a CCITT CRC-16, though it looks close.
static uint16_t crctable[] =
    {
        0x0000,
        0x1021,
        0x2042,
        0x3063,
        0x4084,
        0x50a5,
        0x60c6,
        0x70e7,
        0x8108,
        0x9129,
        0xa14a,
        0xb16b,
        0xc18c,
        0xd1ad,
        0xe1ce,
        0xf1ef,
};

//Calculates the magical CRC value
uint16_t calculateCRC(uint8_t *u8Buf, uint8_t len)
{
  uint16_t crc = 0xFFFF;
  int i;
  for (i = 0; i < len; i++)
  {
    crc = ((crc << 4) | (u8Buf[i] >> 4)) ^ crctable[crc >> 12];
    crc = ((crc << 4) | (u8Buf[i] & 0x0F)) ^ crctable[crc >> 12];
  }

  return crc;
}

void setHandle(UART_Handle inputhandle)
{
    uxhandle = inputhandle;
}

//Get the version number from the module
void getVersion(void)
{
  sendMessage(TMR_SR_OPCODE_VERSION, 0, 0, true);
}

//Given an opcode, a piece of data, and the size of that data, package up a sentence and send it
void sendMessage(uint8_t opcode, uint8_t *data, uint8_t size, bool waitforresponse)
{
  msg[1] = size; //Load the length of this operation into msg array
  msg[2] = opcode;

  //Copy the data into msg array
  uint16_t x;
  for (x = 0; x < size; x++)
      msg[x + 3] = data[x];

  sendCommand(waitforresponse); //Send and wait for response
}
bool startReading(void)
{
    bool disableFilterResult;
    disableFilterResult = disableFilter();
    uint8_t configBlob[] = {0x00, 0x00, 0x01, 0x22, 0x00, 0x00, 0x05, 0x07, 0x22, 0x10, 0x00, 0x1B, 0x03, 0xE8, 0x01, 0xFF};
    sendMessage(TMR_SR_OPCODE_MULTI_PROTOCOL_TAG_OP, configBlob, sizeof(configBlob), true);
    if ((msg[0] == ALL_GOOD) && (disableFilterResult == true))
        return true;
    else
        return false;
}
//Allows for the reading of all tags
bool disableFilter(void)
{
    return setReaderConfiguration(0x0C, 0x00);
}
//Given an array, calc CRC, assign header, send it out
//Modifies the caller's msg array
void sendCommand(bool waitforresponse)
{
  msg[0] = 0xFF; //Universal header
  uint8_t messageLength = msg[1];

  uint8_t opcode = msg[2]; //Used to see if response from module has the same opcode

  //Attach CRC
  uint16_t crc = calculateCRC(&msg[1], messageLength + 2); //Calc CRC starting from spot 1, not 0. Add 2 for LEN and OPCODE bytes.
  msg[messageLength + 3] = crc >> 8;
  msg[messageLength + 4] = crc & 0xFF;

  // TODO print command-to-be-sent onto debug terminal

  // wait until uart not busy
  while (CC_Get_UART_Busy_Status_Reader());

  // initiate send to module
  CC_Start_UART_Write_Reader(msg, messageLength + 5);

  // return after send complete if we don't need response
  if (!waitforresponse)
  {
      while (CC_Get_UART_Write_Status_Reader() == 0);
      return;
  }

  // if we do need response still gotta wait til send is done
  while (CC_Get_UART_Write_Status_Reader() == 0);

  // Layout of response in data array:
  // [0] [1] [2] [3]      [4]      [5] [6]  ... [LEN+4] [LEN+5] [LEN+6]
  // FF  LEN OP  STATUSHI STATUSLO xx  xx   ... xx      CRCHI   CRCLO

  // start timeout timer
  CC_Timeout_Start(2000);
  // read 1st 2 bytes to get header (0xFF) and size
  uint8_t read_buffer1 [2];
  uint8_t read_buffer2 [MAX_MSG_SIZE - 2];
  CC_Start_UART_Read_Reader(read_buffer1, 2);
//  UART_readPolling(uxhandle, &read_buffer1, 2);
  // wait until first 2 bytes read is done
  while (CC_Get_UART_Read_Status_Reader() == 0)
  {
      // check for timeout
      if (CC_Get_Timeout_Status())
      {
          timeoutEscape();
          CC_UART_Read_Cancel_Reader();
          break;
      }
  }
  // get length of REMAINDER OF response
  messageLength = read_buffer1[1] + 5;
  // Read the remainder of the packet
  CC_Start_UART_Read_Reader(read_buffer2, messageLength);
  // wait until read is complete
  while (CC_Get_UART_Read_Status_Reader() == 0)
  {
      // check for timeout
      if (CC_Get_Timeout_Status())
      {
          timeoutEscape();
          CC_UART_Read_Cancel_Reader();
          break;
      }
  }
  // stop timeout timer
  CC_Timeout_Cancel();
  CC_Reset_Timeout();

  // Put Read contents into global msg buffer
  uint8_t i;
  for (i = 0; i < 2; i++)
  {
      msg[i] = read_buffer1[i];
  }
  for (i = 2; i < (messageLength + 2); i++)
  {
      msg[i] = read_buffer2[i - 2];
  }


  // TODO: print response packet to debug term

  // Normalize messageLength to true length (add back header and size byte => +2)
  messageLength += 2;
  // Confirm Response CRC
  crc = calculateCRC(&msg[1], messageLength - 3); //Remove header, remove 2 crc bytes

  // Bad CRC case
  if ((msg[messageLength - 2] != (crc >> 8)) || (msg[messageLength - 1] != (crc & 0xFF)))
  {
    msg[0] = ERROR_CORRUPT_RESPONSE;
    // TODO: print corrupt response error msg to debug
    return;
  }

  // If CRC good, check response packet opcode matches command opcode
  if (msg[2] != opcode)
  {
    msg[0] = ERROR_WRONG_OPCODE_RESPONSE;
    // TODO: print wrong opcode response error msg to debug
    return;
  }

  // Everything matches, put OK
  msg[0] = ALL_GOOD;
}

// @param[in] powerSetting
// Range: 1005-2700 = 10.05dB-27.00dB
void setReadPower(int16_t powerSetting)
{
    if (powerSetting > 2700)
      powerSetting = 2700; //Limit to 27dBm

    //Copy this setting into a temp data array
    uint8_t size = sizeof(powerSetting);
    uint8_t data[size];
    uint8_t x;
    for (x = 0; x < size; x++)
      data[x] = (uint8_t)(powerSetting >> (8 * (size - 1 - x)));

    sendMessage(TMR_SR_OPCODE_SET_READ_TX_POWER, data, size, true);
}
void setRegion(uint8_t region)
{
  sendMessage(TMR_SR_OPCODE_SET_REGION, &region, sizeof(region), true);
}

//See parseResponse for breakdown of fields
//Pulls the number of EPC bytes out of the response
//Often this is 12 bytes
uint8_t getTagEPCBytes(void)
{
  uint16_t epcBits = 0; //Number of bits of EPC (including PC, EPC, and EPC CRC)

  uint8_t tagDataBytes = getTagDataBytes(); //We need this offset
  uint8_t x;
  for (x = 0; x < 2; x++)
    epcBits |= (uint16_t)msg[27 + tagDataBytes + x] << (8 * (1 - x));
  uint8_t epcBytes = epcBits / 8;
  epcBytes -= 4; //Ignore the first two bytes and last two bytes

  return (epcBytes);
}

//See parseResponse for breakdown of fields
//Pulls the number of data bytes out of the response
//Often this is zero
uint8_t getTagDataBytes(void)
{
  //Number of bits of embedded tag data
  uint8_t tagDataLength = 0;
  uint8_t x;
  for (x = 0; x < 2; x++)
    tagDataLength |= (uint16_t)msg[24 + x] << (8 * (1 - x));
  uint8_t tagDataBytes = tagDataLength / 8;
  if (tagDataLength % 8 > 0)
    tagDataBytes++; //Ceiling trick

  return (tagDataBytes);
}

//See parseResponse for breakdown of fields
//Pulls the RSSI value from a full response record stored in msg
int8_t getTagRSSI(void)
{
  return (readmsg[12] - 256);
}
//This will parse whatever response is currently in msg into its constituents
//Mostly used for parsing out the tag IDs and RSSI from a multi tag continuous read
uint8_t parseResponse(void)
{
  //See http://www.thingmagic.com/images/Downloads/Docs/AutoConfigTool_1.2-UserGuide_v02RevA.pdf
  //for a breakdown of the response packet

  //Example response:
  //FF  28  22  00  00  10  00  1B  01  FF  01  01  C4  11  0E  16
  //40  00  00  01  27  00  00  05  00  00  0F  00  80  30  00  00
  //00  00  00  00  00  00  00  00  00  15  45  E9  4A  56  1D
  //  [0] FF = Header
  //  [1] 28 = Message length
  //  [2] 22 = OpCode
  //  [3, 4] 00 00 = Status
  //  [5 to 11] 10 00 1B 01 FF 01 01 = RFU 7 bytes
  //  [12] C4 = RSSI
  //  [13] 11 = Antenna ID (4MSB = TX, 4LSB = RX)
  //  [14, 15, 16] 0E 16 40 = Frequency in kHz
  //  [17, 18, 19, 20] 00 00 01 27 = Timestamp in ms since last keep alive msg
  //  [21, 22] 00 00 = phase of signal tag was read at (0 to 180)
  //  [23] 05 = Protocol ID
  //  [24, 25] 00 00 = Number of bits of embedded tag data [M bytes]
  //  [26 to M] (none) = Any embedded data
  //  [26 + M] 0F = RFU reserved future use
  //  [27, 28 + M] 00 80 = EPC Length [N bytes]  (bits in EPC including PC and CRC bits). 128 bits = 16 bytes
  //  [29, 30 + M] 30 00 = Tag EPC Protocol Control (PC) bits
  //  [31 to 42 + M + N] 00 00 00 00 00 00 00 00 00 00 15 45 = EPC ID
  //  [43, 44 + M + N] 45 E9 = EPC CRC
  //  [45, 46 + M + N] 56 1D = Message CRC

  uint8_t msgLength = msg[1] + 7; //Add 7 (the header, length, opcode, status, and CRC) to the LEN field to get total bytes
  uint8_t opCode = msg[2];


  //Check the CRC on this response
  uint16_t messageCRC = calculateCRC(&msg[1], msgLength - 3); //Ignore header (start spot 1), remove 3 bytes (header + 2 CRC)
  if ((msg[msgLength - 2] != (messageCRC >> 8)) || (msg[msgLength - 1] != (messageCRC & 0xFF)))
  {
    return (ERROR_CORRUPT_RESPONSE);
  }

  if (opCode == TMR_SR_OPCODE_READ_TAG_ID_MULTIPLE) //opCode = 0x22
  {
    //Based on the record length identify if this is a tag record, a temperature sensor record, or a keep-alive?
    if (msg[1] == 0x00) //Keep alive
    {
      //We have a Read cycle reset/keep-alive message
      //Sent once per second
      uint16_t statusMsg = 0;
      uint8_t x;
      for (x = 0; x < 2; x++)
        statusMsg |= (uint32_t)msg[3 + x] << (8 * (1 - x));

      if (statusMsg == 0x0400)
      {
        return (RESPONSE_IS_KEEPALIVE);
      }
      else if (statusMsg == 0x0504)
      {
        return (RESPONSE_IS_TEMPTHROTTLE);
      }
    }
    else if (msg[1] == 0x08) //Unknown
    {
      return (RESPONSE_IS_UNKNOWN);
    }
    else if (msg[1] == 0x0a) //temperature
    {
      return (RESPONSE_IS_TEMPERATURE);
    }
    else //Full tag record
    {
      //This is a full tag response
      //User can now pull out RSSI, frequency of tag, timestamp, EPC, Protocol control bits, EPC CRC, CRC
      return (RESPONSE_IS_TAGFOUND);
    }
  }
  return (ERROR_UNKNOWN_OPCODE);
}


//Sets the protocol of the module
//Currently only GEN2 has been tested and supported but others are listed here for reference
//and possible future support
//TMR_TAG_PROTOCOL_NONE              = 0x00
//TMR_TAG_PROTOCOL_ISO180006B        = 0x03
//TMR_TAG_PROTOCOL_GEN2              = 0x05
//TMR_TAG_PROTOCOL_ISO180006B_UCODE  = 0x06
//TMR_TAG_PROTOCOL_IPX64             = 0x07
//TMR_TAG_PROTOCOL_IPX256            = 0x08
//TMR_TAG_PROTOCOL_ATA               = 0x1D
void setTagProtocol(uint8_t protocol)
{
  uint8_t data[2];
  data[0] = 0; //Opcode expects 16-bits
  data[1] = protocol;

  sendMessage(TMR_SR_OPCODE_SET_TAG_PROTOCOL, data, sizeof(data), true);
}


//Sets the TX and RX antenna ports to 01
//Because the Nano module has only one antenna port, it is not user configurable
void setAntennaPort(void)
{
  uint8_t configBlob[] = {0x01, 0x01}; //TX port = 1, RX port = 1
  sendMessage(TMR_SR_OPCODE_SET_ANTENNA_PORT, configBlob, sizeof(configBlob), true);
}

//Set baud rate
//Takes in a baud rate
//Returns response in the msg array
void setBaud(long baudRate)
{
  //Copy this setting into a temp data array
  uint8_t size = sizeof(baudRate);
  uint8_t data[size];
  uint8_t x;
  for (x = 0; x < size; x++)
    data[x] = (uint8_t)(baudRate >> (8 * (size - 1 - x)));

  sendMessage(TMR_SR_OPCODE_SET_BAUD_RATE, data, size, true);
}

void timeoutEscape(void)
{
    msg[0] = ERROR_COMMAND_RESPONSE_TIMEOUT;
}

void CC_initM6ENano(void)
{
    // turn on M6E Nano by setting enable line high
    setM6EEnablePin(M6ENANO_ON);

    // wait 2s before initializing uart (time to let nano spit out garbage)
    CC_Timeout_Start(2000);
    while (!CC_Get_Timeout_Status());
    CC_Reset_Timeout();

    // initialize uart for comm with m6e nano
    CC_Reader_UART_Init();
}

bool CC_startM6ENano(void)
{
    // call getVersion to check if baud is correct
    getVersion();

    // if wrong response opcode, baud is ok but it is already doing continuous reads
    if (msg[0] == ERROR_WRONG_OPCODE_RESPONSE)
    {
#ifdef DEBUG_PRINT
        UART_PRINT("Wrong OPC response to 1st getVersion call - stopping tag reads.\n\r");
#endif
        // stop reading
        stopReading();
        // delay 1500ms
        CC_Blocking_Delay(1500);
    }

    // if other option, we'll assume device is at wrong baud
    else
    {
        // set m6e nano baud
        setBaud(115200);
#ifdef DEBUG_PRINT
        if (msg[0] == ALL_GOOD)
            UART_PRINT("Success setting baud to 115200.\n\r");
        else
            UART_PRINT("ERROR: bad response to setBaud command!\n\r");
#endif
        // delay 2000ms
        CC_Blocking_Delay(2000);
    }

    // Connection should be good now
    getVersion();

    // unknown error comm with m6e nano
    // go into test escape
    if (msg[0] != ALL_GOOD)
    {
#ifdef DEBUG_PRINT
        UART_PRINT("ERROR: Failure communicating with M6E Nano! Trying again.\n\r");
#endif
        return false;
    }

    // if we're "all good" put in last few settings (confirm good response for all)
    // if failure of any config, go into test escape
    setTagProtocol(0x05);
    if (msg[0] == ALL_GOOD)
    {
#ifdef DEBUG_PRINT
        UART_PRINT("Successfully set tag protocol.\n\r");
#endif
    }
    else
    {
#ifdef DEBUG_PRINT
        UART_PRINT("ERROR: failure setting tag protocol!\n\r");
#endif
        return false;
    }
    setAntennaPort();
    if (msg[0] == ALL_GOOD)
    {
#ifdef DEBUG_PRINT
        UART_PRINT("Successfully set antenna port.\n\r");
#endif
    }
    else
    {
#ifdef DEBUG_PRINT
        UART_PRINT("ERROR: failure setting antenna port!\n\r");
#endif
        return false;
    }
    setRegion(REGION_NORTHAMERICA);
    if (msg[0] == ALL_GOOD)
    {
#ifdef DEBUG_PRINT
        UART_PRINT("Successfully set region.\n\r");
#endif
    }
    else
    {
#ifdef DEBUG_PRINT
        UART_PRINT("ERROR: failure setting region!\n\r");
#endif
        return false;
    }
    setReadPower(M6ENANO_READ_POWER);
    if (msg[0] == ALL_GOOD)
    {
#ifdef DEBUG_PRINT
        UART_PRINT("Successfully set read power.\n\r");
#endif
    }
    else
    {
#ifdef DEBUG_PRINT
        UART_PRINT("ERROR: failure setting read power!\n\r");
#endif
        return false;
    }

    ///////////// IT STOP 1 //////////////////////
    // at this point the m6e nano has been successfully initialized and started

    if (startReading())
    {
#ifdef DEBUG_PRINT
        UART_PRINT("Successfully disabled read filter - searching for tags now.\n\r");
#endif
    }
    else
    {
#ifdef DEBUG_PRINT
        UART_PRINT("ERROR: failure disabling read filter!\n\r");
#endif
        return false;
    }
    return true;
}

void stopReading(void)
{
    //00 00 = Timeout, currently ignored
    //02 = Option - stop continuous reading
    uint8_t configBlob[] = {0x00, 0x00, 0x02};

    sendMessage(TMR_SR_OPCODE_MULTI_PROTOCOL_TAG_OP, configBlob, sizeof(configBlob), false); //Do not wait for response
}

bool setReaderConfiguration(uint8_t option1, uint8_t option2)
{
    uint8_t data[3];

    //These are parameters gleaned from inspecting the 'Transport Logs' of the Universal Reader Assistant
    //And from serial_reader_l3.c
    data[0] = 1; //Key value form of command
    data[1] = option1;
    data[2] = option2;

    sendMessage(TMR_SR_OPCODE_SET_READER_OPTIONAL_PARAMS, data, sizeof(data), true);
    if (msg[0] == ALL_GOOD)
        return true;
    else
        return false;
}

// turns reader on or off
// setting = if true, enable = high (turns on m6e nano)
//           if false, enable = low (turns off m6e nano)
void setM6EEnablePin(bool setting)
{
    if (setting)
        GPIO_write(M6E_ENABLE_GPIO, 1);

    else if (!setting)
        GPIO_write(M6E_ENABLE_GPIO, 0);
}

//          - simply reads for incoming header byte and sends uart message when one comes in
//          - if on index 0 - check/wait for incoming header byte (0xFF), ignore others
//          - if above index 0, simply read bytes until end of packet (based on size byte)
bool checkDataBus(void)
{
    static uint8_t ctr = 0; // array counter to fill global msg array
    uint8_t byte;
    // only attempt read if bus not busy
    if (CC_Get_UART_Read_Status_Reader())
    {
        CC_Start_UART_Read_Reader(&byte, 1);
        while (!(CC_Get_UART_Read_Status_Reader()));
    }
    if (ctr == 0 && byte != 0xFF)
        return false;
    else
    {
        msg[ctr] = byte;
        ctr++;
        // print error msg if buffer attempts to wrap
#ifdef DEBUG_PRINT
        if (ctr > 250)
            UART_PRINT("WARNING: checkDataBus gettin pretty full.\n\r");
#endif
        // full packet received
        if (ctr > 0 && (ctr == msg[1] + 7))
        {
            uint8_t i;
            // erase remainder of array
            for (i = ctr; i < MAX_MSG_SIZE; i++)
                msg[i] = 0;

            // reset counter
            ctr = 0;
            // return true when good packet found
            return true;
        }
        return false;
    }
}

void flushM6EBuffer(void)
{
    uint32_t i;
    for (i = 0; i < MAX_MSG_SIZE; i++)
        msg[i] = 0x0;
}

