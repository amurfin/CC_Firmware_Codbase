/*
 * cc_uart_driver.c
 *
 *  Created on: Feb 22, 2021
 *      Author: xps
 */

#include "cc_uart_driver.h"

/* static variables */
// reader uart vairables
static uint8_t uart_write_done_reader = 1;
static uint8_t uart_read_done_reader = 1;
static uint8_t uart_busy_reader = 0;
static UART_Handle u0handle;
// elesim uart variables
static uint8_t uart_write_done_elesim = 1;
static uint8_t uart_read_done_elesim = 1;
static uint8_t uart_busy_elesim = 0;
static UART_Handle u1handle;

/* local functions */

void CC_Debug_UART_Init(void)
{
#ifdef DEBUG_PRINT
    InitTerm();
    UART_PRINT("Contactless Card Reader Module Debug ");
#ifdef UART_USING_DEVBOARD
    UART_PRINT("Running On CC3220 Dev Board\n\r");
#endif // #ifdef UART_USING_DEVBOARD
#ifdef UART_USING_REV2
    UART_PRINT("Running On CC Reader Rev2\n\r");
#endif // #ifdef UART_USING_REV2
#endif
}

void CC_Elesim_UART_Init(void)
{
#ifdef UART_USING_ELESIM
    /* this may not be necessary */
    // MUX Pins: 7 = U1TX, 8 = U1RX
//    PinTypeUART(PIN_07, PIN_MODE_5);
//    PinTypeUART(PIN_08, PIN_MODE_5);

    // Init UART1 parameters
    UART_Params u1params;
    UART_Params_init(&u1params);
    u1params.readMode = UART_MODE_CALLBACK;
    u1params.writeMode = UART_MODE_CALLBACK;
    u1params.readCallback = CC_UART_Read_Callback_Elesim;
    u1params.writeCallback = CC_UART_Write_Callback_Elesim1;
    u1params.writeDataMode = UART_DATA_BINARY;
    u1params.readDataMode = UART_DATA_BINARY;
    u1params.readReturnMode = UART_RETURN_FULL;
    u1params.readEcho = UART_ECHO_OFF;
    u1params.baudRate = 115200;
    // Open UART
    u1handle = UART_open(UART_1_ELESIM, &u1params);
    if (u1handle == NULL)
    {
        // UART_open() failed
        while (1);
    }
#ifdef DEBUG_PRINT
    // print success msg
    UART_PRINT("UART1 Successfully Opened for rev2 board comm with elesim on p07 and p08\n\r");
#endif
    // UART1 ready
#endif
    readElesim = true;
}

void CC_UART_Write_Callback_Reader(UART_Handle handle, void *buf, size_t count)
{
    uart_write_done_reader = 1;
    if (uart_write_done_reader && uart_read_done_reader)
        uart_busy_reader = 0;
}


void CC_UART_Read_Callback_Reader(UART_Handle handle, void *buf, size_t count)
{
    uart_read_done_reader = 1;
    if (uart_write_done_reader && uart_read_done_reader)
        uart_busy_reader = 0;
}

uint8_t CC_Get_UART_Write_Status_Reader(void)
{
    return uart_write_done_reader;
}

uint8_t CC_Get_UART_Read_Status_Reader(void)
{
    return uart_read_done_reader;
}

void CC_Start_UART_Write_Reader(const uint8_t * buffer, size_t size)
{
    uart_write_done_reader = 0;
    uart_busy_reader = 1;
    UART_write(u0handle, buffer, size);
}

void CC_Start_UART_Read_Reader(uint8_t * buffer, size_t size)
{
    uart_read_done_reader = 0;
    uart_busy_reader = 1;
    UART_read(u0handle, buffer, size);
}

uint8_t CC_Get_UART_Busy_Status_Reader(void)
{
    return uart_busy_reader;
}

void CC_UART_Read_Cancel_Reader(void)
{
    UART_readCancel(u0handle);
}

void CC_Reader_UART_Init(void)
{
#ifdef UART_USING_DEVBOARD
    /* this may not be necessary */
    // MUX Pins: 7 = U1TX, 8 = U1RX
    PinTypeUART(PIN_07, PIN_MODE_5);
    PinTypeUART(PIN_08, PIN_MODE_5);

    // Init UART1 parameters
    UART_Params u1params;
    UART_Params_init(&u1params);
    u1params.readMode = UART_MODE_CALLBACK;
    u1params.writeMode = UART_MODE_CALLBACK;
    u1params.readCallback = CC_UART_Read_Callback;
    u1params.writeCallback = CC_UART_Write_Callback;
    u1params.writeDataMode = UART_DATA_BINARY;
    u1params.readDataMode = UART_DATA_BINARY;
    u1params.readReturnMode = UART_RETURN_FULL;
    u1params.readEcho = UART_ECHO_OFF;
    u1params.baudRate = 115200;
    // Open UART
    u0handle = UART_open(UART_1_TO_M6E, &u1params);
    if (u0handle == NULL)
    {
        // UART_open() failed
        while (1);
    }
    // set handle in m6e driver
    setHandle(u0handle);
    // print success msg
    UART_PRINT("UART1 Successfully Opened for devboard comm with m6e nano on p07 & p08\n\r");
    // UART1 ready
#endif // #ifdef UART_USING_DEVBOARD
#ifdef UART_USING_REV2
    /* this may not be necessary */
    // MUX Pins: 3 = U0TX, 4 = U0RX
    PinTypeUART(PIN_03, PIN_MODE_7);
    PinTypeUART(PIN_04, PIN_MODE_7);

    // Init UART1 parameters
    UART_Params u0params;
    UART_Params_init(&u0params);
    u0params.readMode = UART_MODE_CALLBACK;
    u0params.writeMode = UART_MODE_CALLBACK;
    u0params.readCallback = CC_UART_Read_Callback_Reader;
    u0params.writeCallback = CC_UART_Write_Callback_Reader;
    u0params.writeDataMode = UART_DATA_BINARY;
    u0params.readDataMode = UART_DATA_BINARY;
    u0params.readReturnMode = UART_RETURN_FULL;
    u0params.readEcho = UART_ECHO_OFF;
    u0params.baudRate = 115200;
    // Open UART
    u0handle = UART_open(UART_0_TO_M6E, &u0params);
    if (u0handle == NULL)
    {
        // UART_open() failed
        while (1);
    }
    // set handle in m6e driver
    setHandle(u0handle);
#ifdef DEBUG_PRINT
    // print success msg
    UART_PRINT("UART0 Successfully Opened for rev2 board comm with m6e nano on p03 & p04\n\r");
#endif
    // UART0 ready
#endif // #ifdef UART_USING_REV2
}

void CC_UART_Write_Callback_Elesim1(UART_Handle handle, void *buf, size_t count)
{
    uart_write_done_elesim = 1;
    if (uart_write_done_elesim && uart_read_done_elesim)
        uart_busy_elesim = 0;
}

void CC_UART_Read_Callback_Elesim(UART_Handle handle, void *buf, size_t count)
{
    uart_read_done_elesim = 1;
    if (uart_write_done_elesim && uart_read_done_elesim)
        uart_busy_elesim = 0;
    // post semaphore for elesimRecvThread if received 4 bytes
    if (count == 4)
    {
        readElesim = true;
        CC_Handle_Elesim_Response(dataFromElesim);
    }

}

uint8_t CC_Get_UART_Write_Status_Elesim(void)
{
    return uart_write_done_elesim;
}

uint8_t CC_Get_UART_Read_Status_Elesim(void)
{
    return uart_read_done_elesim;
}

void CC_Start_UART_Write_Elesim(const uint8_t * buffer, size_t size)
{
    uart_write_done_elesim = 0;
    uart_busy_elesim = 1;
    UART_write(u1handle, buffer, size);
}

void CC_Start_UART_Read_Elesim(uint8_t * buffer, size_t size)
{
    uart_read_done_elesim = 0;
    uart_busy_elesim = 1;
    UART_read(u1handle, buffer, size);
}

uint8_t CC_Get_UART_Busy_Status_Elesim(void)
{
    return uart_busy_elesim;
}

void CC_UART_Read_Cancel_Elesim(void)
{
    UART_readCancel(u1handle);
}
