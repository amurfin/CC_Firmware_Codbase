/*
 * cc_app.c
 *
 *  Created on: Feb 22, 2021
 *      Author: xps
 */

#include "cc_app.h"

/* local functions */

// initializes specific hardware for cc reader duties
void CC_App_Init(void)
{
    GPIO_init();
    // assert M6E enable line low
    setM6EEnablePin(M6ENANO_OFF);
    SPI_init();

#ifdef DEBUG_PRINT
    CC_Debug_UART_Init();
#else
    UART_init();
#endif
    // initialize timer0 for timeout timer
    CC_Timer_Init();

    // initialize m6e nano for application functionality
    CC_initM6ENano();
    // initialize uart1 to elesim
    CC_Elesim_UART_Init();
    // attempts reset and restart of m6e nano if it fails, until it succeeds
    while (!(CC_startM6ENano()))
    {
        setM6EEnablePin(M6ENANO_OFF);
        CC_Blocking_Delay(1000);
        setM6EEnablePin(M6ENANO_ON);
        CC_Blocking_Delay(2000);
    }


}
