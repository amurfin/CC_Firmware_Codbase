/*
 * cc_app.h
 *
 *  Created on: Feb 22, 2021
 *      Author: xps
 */

#ifndef CC_APP_H_
#define CC_APP_H_

/* includes */
#include <stdint.h>
/* TI-DRIVERS Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/SPI.h>
#include <ti/drivers/UART.h>
#include <ti/drivers/Power.h>
#include <ti/drivers/net/wifi/simplelink.h>
#include "cc_uart_driver.h"
#include "cc_timer_driver.h"
#include "CCReaderMainThread.h"

/* defines */
#define SPAWN_TASK_PRIORITY     (9)
#define SPAWN_TASK_STACK_SIZE   (2048)
//#define CC_USING_DEVBOARD_DEBUG

/* local function prototypes */
void CC_App_Init(void);



#endif /* CC_APP_H_ */
