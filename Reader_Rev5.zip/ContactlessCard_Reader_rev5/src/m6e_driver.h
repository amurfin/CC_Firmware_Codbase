/*
 * m6e_driver.h
 *
 *  Created on: Nov 22, 2020
 *      Author: xps
 */

/* includes */
#include <stdint.h>
#include <ti/drivers/UART.h>
#include <ti/drivers/uart/UARTCC32XX.h>
#include "cc_timer_driver.h"
#include "cc_uart_driver.h"

#ifndef M6E_DRIVER_H_
#define M6E_DRIVER_H_

/* defines */
#define MAX_MSG_SIZE 255

#define TMR_SR_OPCODE_VERSION 0x03
#define TMR_SR_OPCODE_SET_BAUD_RATE 0x06
#define TMR_SR_OPCODE_READ_TAG_ID_SINGLE 0x21
#define TMR_SR_OPCODE_READ_TAG_ID_MULTIPLE 0x22
#define TMR_SR_OPCODE_WRITE_TAG_ID 0x23
#define TMR_SR_OPCODE_WRITE_TAG_DATA 0x24
#define TMR_SR_OPCODE_KILL_TAG 0x26
#define TMR_SR_OPCODE_READ_TAG_DATA 0x28
#define TMR_SR_OPCODE_CLEAR_TAG_ID_BUFFER 0x2A
#define TMR_SR_OPCODE_MULTI_PROTOCOL_TAG_OP 0x2F
#define TMR_SR_OPCODE_GET_READ_TX_POWER 0x62
#define TMR_SR_OPCODE_GET_WRITE_TX_POWER 0x64
#define TMR_SR_OPCODE_GET_POWER_MODE 0x68
#define TMR_SR_OPCODE_GET_READER_OPTIONAL_PARAMS 0x6A
#define TMR_SR_OPCODE_GET_PROTOCOL_PARAM 0x6B
#define TMR_SR_OPCODE_SET_ANTENNA_PORT 0x91
#define TMR_SR_OPCODE_SET_TAG_PROTOCOL 0x93
#define TMR_SR_OPCODE_SET_READ_TX_POWER 0x92
#define TMR_SR_OPCODE_SET_WRITE_TX_POWER 0x94
#define TMR_SR_OPCODE_SET_REGION 0x97
#define TMR_SR_OPCODE_SET_READER_OPTIONAL_PARAMS 0x9A
#define TMR_SR_OPCODE_SET_PROTOCOL_PARAM 0x9B

#define COMMAND_TIME_OUT 2000 //Number of ms before stop waiting for response from module

//Define all the ways functions can return
#define ALL_GOOD 0
#define ERROR_COMMAND_RESPONSE_TIMEOUT 1
#define ERROR_CORRUPT_RESPONSE 2
#define ERROR_WRONG_OPCODE_RESPONSE 3
#define ERROR_UNKNOWN_OPCODE 4
#define RESPONSE_IS_TEMPERATURE 5
#define RESPONSE_IS_KEEPALIVE 6
#define RESPONSE_IS_TEMPTHROTTLE 7
#define RESPONSE_IS_TAGFOUND 8
#define RESPONSE_IS_NOTAGFOUND 9
#define RESPONSE_IS_UNKNOWN 10
#define RESPONSE_SUCCESS 11
#define RESPONSE_FAIL 12

//Define the allowed regions - these set the internal freq of the module
#define REGION_INDIA 0x04
#define REGION_JAPAN 0x05
#define REGION_CHINA 0x06
#define REGION_EUROPE 0x08
#define REGION_KOREA 0x09
#define REGION_AUSTRALIA 0x0B
#define REGION_NEWZEALAND 0x0C
#define REGION_NORTHAMERICA 0x0D
#define REGION_OPEN 0xFF
//#define DEBUG_PRINT

// other defines
#define M6ENANO_ON          true
#define M6ENANO_OFF         false
#define M6ENANO_READ_POWER  1200

/* global variables */
  //This is our universal msg array, used for all communication
  //Before sending a command to the module we will write our command and CRC into it
  //And before returning, response will be recorded into the msg array. Default is 255 bytes.
  uint8_t msg[MAX_MSG_SIZE];
  uint8_t readmsg[MAX_MSG_SIZE];

/* functions */
void sendCommand(bool waitforresponse);
bool disableFilter(void);
bool startReading(void);
void setReadPower(int16_t powerSetting);
void setRegion(uint8_t region);
uint8_t getTagEPCBytes(void);
uint8_t getTagDataBytes(void);
uint8_t parseResponse(void);
int8_t getTagRSSI(void);
void sendMessage(uint8_t opcode, uint8_t *data, uint8_t size, bool waitforresponse);
void getVersion(void);
void setHandle(UART_Handle inputhandle);
uint16_t calculateCRC(uint8_t *u8Buf, uint8_t len);
void setTagProtocol(uint8_t protocol);
void setAntennaPort(void);
void setBaud(long baudRate);
void timeoutEscape(void);
void CC_initM6ENano(void);
bool CC_startM6ENano(void);
void stopReading(void);
bool setReaderConfiguration(uint8_t option1, uint8_t option2);
void setM6EEnablePin(bool setting);
bool checkDataBus(void);
void flushM6EBuffer(void);



#endif /* M6E_DRIVER_H_ */
