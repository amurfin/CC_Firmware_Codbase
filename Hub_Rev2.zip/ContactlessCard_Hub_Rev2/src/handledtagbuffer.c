/*
 * handledtagbuffer.c
 *
 *  Created on: Apr 19, 2021
 *      Author: AMurfin
 */
// INCLUDE FILES //
#include "handledtagbuffer.h"

// FUNCTIONS //

// note for all functions: do work, THEN increment master counter
// note for all functions:

void flush_tag_buffer(void)
{
    uint8_t x;
    uint8_t y;
    // init master buffer counter
    masterBufferCtr = 0;
    // init all items in buffer to null values
    for (x = BUFFER_MIN; x < HANDLED_BUFFER_MAX; x++)
    {
        handledTagBuffer[x].floor10 = NULL;
        handledTagBuffer[x].floor1 = NULL;
        handledTagBuffer[x].served = SERVED_INIT_STATE;
        // init all elements of tag to null
        for (y = BUFFER_MIN; y < TAG_BUFFER_MAX; y++)
            handledTagBuffer[x].tag[y] = NULL;
    }
}

void add_to_buffer(uint8_t newTag[64], uint8_t floor10, uint8_t floor1)
{
    uint8_t x;
    // set values of new tag to their input values
    handledTagBuffer[masterBufferCtr].floor10 = floor10;
    handledTagBuffer[masterBufferCtr].floor1 = floor1;
    handledTagBuffer[masterBufferCtr].served = SERVED_INIT_STATE;
    // set all elements of tag to match input tag
    for (x = BUFFER_MIN; x < TAG_BUFFER_MAX; x++)
    {
        handledTagBuffer[masterBufferCtr].tag[x] = newTag[x];
    }
    // increment master counter if not at max
    if (masterBufferCtr < HANDLED_BUFFER_MAX)
        masterBufferCtr++;
    // wrap to zero if at max
    else if (masterBufferCtr == HANDLED_BUFFER_MAX)
        masterBufferCtr = 0;
}

void service_floor(uint8_t floor10, uint8_t floor1)
{
    uint8_t x;

    // set the served bit if their floor 10 and 1 matches
    for (x = BUFFER_MIN; x < HANDLED_BUFFER_MAX; x++)
    {
        if (handledTagBuffer[x].floor10 == floor10 && handledTagBuffer[x].floor1 == floor1)
            handledTagBuffer[x].served = SERVED_TRUE_STATE;
    }
}

void delete_floor(uint8_t floor10, uint8_t floor1)
{
    uint8_t x;
    uint8_t y;

    // set to null all elements in a buffer
    for (x = BUFFER_MIN; x < HANDLED_BUFFER_MAX; x++)
    {
        if (handledTagBuffer[x].floor10 == floor10 && handledTagBuffer[x].floor1 == floor1)
        {
            handledTagBuffer[x].floor10 = NULL;
            handledTagBuffer[x].floor1 = NULL;
            handledTagBuffer[x].served = SERVED_INIT_STATE;
            for (y = BUFFER_MIN; y < TAG_BUFFER_MAX; y++)
                handledTagBuffer[x].tag[y] = NULL;
        }
    }
}

// return true if a tag is already in the buffer
// return false if not
bool is_in_buffer(uint8_t inquiryTag[64])
{
    uint8_t x;
    uint8_t y;

    // go through all nodes of handledTagBuffer
    for (x = BUFFER_MIN; x < HANDLED_BUFFER_MAX; x++)
    {
        // go through each element of tag
        for (y = BUFFER_MIN; y < TAG_BUFFER_MAX; y++)
        {
            // if any elements of inquiry don't match the buffer node's tag, break to go to next
            // tag buffer element
            if (inquiryTag[y] != handledTagBuffer[x].tag[y])
            {
                break;
            }
            // if we've reached the end of a tag with no differences, it has been found
            if (y == (TAG_BUFFER_MAX - 1))
                return true;
        }
    }
    // if we've gone through all tags of a buffer and found differences in each, return false
    return false;
}
