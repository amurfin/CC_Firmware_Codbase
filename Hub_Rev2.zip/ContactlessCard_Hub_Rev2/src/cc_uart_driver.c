/*
 * cc_uart_driver.c
 *
 *  Created on: Feb 22, 2021
 *      Author: xps
 */

#include "cc_uart_driver.h"

/* static variables */
static uint8_t uart_write_done = 1;
static uint8_t uart_read_done = 1;
static uint8_t uart_busy = 0;
static UART_Handle uxhandle;

/* local functions */

void CC_Debug_UART_Init(void)
{
    InitTerm();
    UART_PRINT("Contactless Card Reader Module Debug ");
#ifdef UART_USING_DEVBOARD
    UART_PRINT("Running On CC3220 Dev Board\n\r");
#endif // #ifdef UART_USING_DEVBOARD
#ifdef UART_USING_REV2
    UART_PRINT("Running On CC Reader Rev2\n\r");
#endif // #ifdef UART_USING_REV2
}

void CC_UART_Write_Callback(UART_Handle handle, void *buf, size_t count)
{
    uart_write_done = 1;
    if (uart_write_done && uart_read_done)
        uart_busy = 0;
}


void CC_UART_Read_Callback(UART_Handle handle, void *buf, size_t count)
{
    uart_read_done = 1;
    if (uart_write_done && uart_read_done)
        uart_busy = 0;
}

uint8_t CC_Get_UART_Write_Status(void)
{
    return uart_write_done;
}

uint8_t CC_Get_UART_Read_Status(void)
{
    return uart_read_done;
}

void CC_Start_UART_Write(const uint8_t * buffer, size_t size)
{
    uart_write_done = 0;
    uart_busy = 1;
    UART_write(uxhandle, buffer, size);
}

void CC_Start_UART_Read(uint8_t * buffer, size_t size)
{
    uart_read_done = 0;
    uart_busy = 1;
    UART_read(uxhandle, buffer, size);
}

uint8_t CC_Get_UART_Busy_Status(void)
{
    return uart_busy;
}

void CC_UART_Read_Cancel(void)
{
    UART_readCancel(uxhandle);
}

void CC_Reader_UART_Init(void)
{
#ifdef UART_USING_DEVBOARD
    /* this may not be necessary */
    // MUX Pins: 7 = U1TX, 8 = U1RX
    PinTypeUART(PIN_07, PIN_MODE_5);
    PinTypeUART(PIN_08, PIN_MODE_5);

    // Init UART1 parameters
    UART_Params u1params;
    UART_Params_init(&u1params);
    u1params.readMode = UART_MODE_CALLBACK;
    u1params.writeMode = UART_MODE_CALLBACK;
    u1params.readCallback = CC_UART_Read_Callback;
    u1params.writeCallback = CC_UART_Write_Callback;
    u1params.writeDataMode = UART_DATA_BINARY;
    u1params.readDataMode = UART_DATA_BINARY;
    u1params.readReturnMode = UART_RETURN_FULL;
    u1params.readEcho = UART_ECHO_OFF;
    u1params.baudRate = 115200;
    // Open UART
    uxhandle = UART_open(UART_1_TO_M6E, &u1params);
    if (uxhandle == NULL)
    {
        // UART_open() failed
        while (1);
    }
    // set handle in m6e driver
    setHandle(uxhandle);
    // print success msg
    UART_PRINT("UART1 Successfully Opened for devboard comm with m6e nano on p07 & p08\n\r");
    // UART1 ready
#endif // #ifdef UART_USING_DEVBOARD
#ifdef UART_USING_REV2
    /* this may not be necessary */
    // MUX Pins: 3 = U0TX, 4 = U0RX
    PinTypeUART(PIN_03, PIN_MODE_7);
    PinTypeUART(PIN_04, PIN_MODE_7);

    // Init UART1 parameters
    UART_Params u0params;
    UART_Params_init(&u0params);
    u0params.readMode = UART_MODE_CALLBACK;
    u0params.writeMode = UART_MODE_CALLBACK;
    u0params.readCallback = CC_UART_Read_Callback;
    u0params.writeCallback = CC_UART_Write_Callback;
    u0params.writeDataMode = UART_DATA_BINARY;
    u0params.readDataMode = UART_DATA_BINARY;
    u0params.readReturnMode = UART_RETURN_FULL;
    u0params.readEcho = UART_ECHO_OFF;
    u0params.baudRate = 115200;
    // Open UART
    uxhandle = UART_open(UART_0_TO_M6E, &u0params);
    if (uxhandle == NULL)
    {
        // UART_open() failed
        while (1);
    }
    // set handle in m6e driver
    setHandle(uxhandle);
    // print success msg
    UART_PRINT("UART0 Successfully Opened for rev2 board comm with m6e nano on p03 & p04\n\r");
    // UART0 ready
#endif // #ifdef UART_USING_REV2
}

