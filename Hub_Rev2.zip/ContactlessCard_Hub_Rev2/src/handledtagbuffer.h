/*
 * handledtagbuffer.h
 *
 *  Created on: Apr 19, 2021
 *      Author: AMurfin
 */

#ifndef SRC_HANDLEDTAGBUFFER_H_
#define SRC_HANDLEDTAGBUFFER_H_

// INCLUDE FILES //
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdint.h>
#include "str.h"
#include "CCReaderMainThread.h"

// DEFINES //
#define BUFFER_MIN          0
#define HANDLED_BUFFER_MAX  64
#define TAG_BUFFER_MAX      64
#define SERVED_INIT_STATE   false
#define SERVED_TRUE_STATE   true

typedef struct handled_tag_node_t
{
    uint8_t floor10;
    uint8_t floor1;
    bool served;
    uint8_t tag[64];
} handled_tag_node_t;

// GLOBAL VARIABLES //
static struct handled_tag_node_t handledTagBuffer[HANDLED_BUFFER_MAX];
static uint8_t            masterBufferCtr;

// FUNCTION PROTOTYPES //
void flush_tag_buffer(void);
void add_to_buffer(uint8_t newTag[64], uint8_t floor10, uint8_t floor1);
void service_floor(uint8_t floor10, uint8_t floor1);
void delete_floor(uint8_t floor10, uint8_t floor1);
bool is_in_buffer(uint8_t inquiryTag[64]);


#endif /* SRC_HANDLEDTAGBUFFER_H_ */
