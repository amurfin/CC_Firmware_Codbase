/*
 * CCReaderMainThread.h
 *
 *  Created on: Apr 19, 2021
 *      Author: xps
 */

#ifndef SRC_CCREADERMAINTHREAD_H_
#define SRC_CCREADERMAINTHREAD_H_

//*****************************************************************************
// Includes
//*****************************************************************************

// Standard includes
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdint.h>
#include "str.h"

/* TI-DRIVERS Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/SPI.h>
#include <ti/drivers/UART.h>
#include <ti/drivers/Power.h>
#include <ti/drivers/net/wifi/simplelink.h>
#include <ti/devices/cc32xx/driverlib/pin.h>
#include <ti/posix/ccs/sys/types.h>

#include "semaphore.h"
#include "pthread.h"
#include "uart_term.h"
#include "unistd.h"
#include "time.h"

/* Contactless Card Header Files */
#include "m6e_driver.h"
#include "cc_uart_driver.h"
#include "cc_app.h"
#include "uart_term.h"
#include "cc_timer_driver.h"
#include "ti_drivers_config.h"
#include "cmd_parser.h"
#include "wlan_cmd.h"
#include "netapp_cmd.h"
#include "socket_cmd.h"
#include "transceiver_cmd.h"
#include "socket_cmd.h"
#include "handledtagbuffer.h"
#include "network_terminal.h"

/* For usleep() */
#include <unistd.h>

//*****************************************************************************
// Defines
//*****************************************************************************
#define TCP_PROTOCOL_FLAGS          0
// CC Reader Macros
#define SEM_INIT_CLEAR                  0u
#define SEM_THREAD_SHARE                0
#define READER_FLOOR_DEFAULT            2u
#define SOCKET_IP                       3232235779u // 192.168.1.3 = 3232235779; 192.168.1.4 = 3232235780
#define SOCKET_PORT                     7410u
#define ELESIM_RECV_TASK_PRIO           1u
#define ELESIM_RECV_TASK_STACK_SIZE     256
#define ELESIM_FLUSH_CMD                0x0
#define ELESIM_SERVICE_FLOOR_CMD        0xFA // TODO give real value
#define ELESIM_DELETE_FLOOR_CMD        0xFB // TODO give real value
#define ELESIM_CHANGE_READER_FLOOR_CMD  0x1
#define SPAWN_TASK_PRIORITY             (3)
#define SPAWN_TASK_STACK_SIZE           (2048)
#define GOTO_FLOOR_10s                  rcvd_cmd[3]
#define GOTO_FLOOR_1s                   rcvd_cmd[4]
//#define DEBUG_PRINT                         // also defined in m6e_driver.h



//*****************************************************************************
// Typedefs
//*****************************************************************************



//*****************************************************************************
// Function prototypes
//*****************************************************************************
void CC_Wifi_Init(void);
void CC_Reader_Socket_Connect(uint16_t portNumber, ip_t ipAddress);
void CC_Reader_Recv_Cmd(void);
void CC_Reader_Get_EPC(void);
void CC_Reader_Tag_Handler(uint8_t size, uint8_t * buffer);
bool CC_Reader_Cmd_Elevator(void);
void CC_Handle_Elesim_Response(uint8_t * elesimResponse);
void CC_Hub_Attachment_Send_New_EPC(void);

//*****************************************************************************
// Globals
//*****************************************************************************
ClockP_Handle CCReader_lpdsHandle;
pthread_t gSpawn_thread;
uint8_t reader_floor;   // dynamically changing reader floor, default val = READER_FLOOR_DEFAULT
static int32_t sockHndl = 0;
static uint8_t rcvd_cmd[5];

#endif /* SRC_CCREADERMAINTHREAD_H_ */
