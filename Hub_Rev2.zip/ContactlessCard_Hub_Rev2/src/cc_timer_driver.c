/*
 * cc_timer_driver.c
 *
 *  Created on: Feb 23, 2021
 *      Author: xps
 */

/* includes */
#include "cc_timer_driver.h"

/* variables */
static uint8_t cc_timeout = 0;
static Timer_Handle cc_timer0_handle;

/* local functions */

// Initializes Timer for CC implementation
// Timer0 will be used as free running timer - used as "timeout" timer for sending and rcving commands
void CC_Timer_Init(void)
{
    // Call timer init function
    Timer_init();
    // Open Timer and test w/ 2 sec
    CC_Timeout_Start(2000);
    // hold in loop until timeout
    while (CC_Get_Timeout_Status() == 0);
    // reset state variable once out of loop
    CC_Reset_Timeout();
    CC_Timeout_Cancel();
}

void CC_Timer_Callback(Timer_Handle handle, int_fast16_t status)
{
    cc_timeout = 1;
    Timer_stop(handle);
    Timer_close(handle);
}

void CC_Timeout_Start(uint32_t ms_timeout)
{
    Timer_Params cc_timer0_params;
    // Init Timer Parameters
    cc_timer0_params.timerMode = Timer_ONESHOT_CALLBACK;
    cc_timer0_params.periodUnits = Timer_PERIOD_US;
    cc_timer0_params.timerCallback = CC_Timer_Callback;
    cc_timer0_params.period = ms_timeout * 1000;
    // open timer
    cc_timer0_handle = Timer_open(CONFIG_TIMER_0, &cc_timer0_params);
    if (cc_timer0_handle == NULL)
        while (1);   // Timer_open() failed
    // start timer
    if (Timer_start(cc_timer0_handle) != Timer_STATUS_SUCCESS)
        while (1); // timer start failed
    // will call callback function when done
}

uint8_t CC_Get_Timeout_Status(void)
{
    return cc_timeout;
}

void CC_Reset_Timeout(void)
{
    cc_timeout = 0;
}

void CC_Timeout_Cancel(void)
{
    Timer_stop(cc_timer0_handle);
    Timer_close(cc_timer0_handle);
}

void CC_Blocking_Delay(uint32_t ms_delay)
{
    while (CC_Get_Timeout_Status());
    CC_Timeout_Start(ms_delay);
    while (!(CC_Get_Timeout_Status()));
    CC_Reset_Timeout();
}



